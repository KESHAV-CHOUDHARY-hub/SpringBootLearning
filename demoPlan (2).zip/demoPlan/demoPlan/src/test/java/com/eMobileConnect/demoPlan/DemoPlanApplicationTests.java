package com.eMobileConnect.demoPlan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoPlanApplicationTests {

	@Test
	void contextLoads() {
	}

}
