package com.eMobileConnect.demoPlan.repository;

import com.eMobileConnect.demoPlan.entity.Plan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Repository extends JpaRepository<Plan, Integer> {
}
