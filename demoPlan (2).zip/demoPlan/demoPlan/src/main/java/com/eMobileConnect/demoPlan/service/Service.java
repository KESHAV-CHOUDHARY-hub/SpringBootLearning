package com.eMobileConnect.demoPlan.service;

import com.eMobileConnect.demoPlan.entity.Number;
import com.eMobileConnect.demoPlan.entity.Plan;

import java.util.List;

public interface Service {
    String savePlan(Plan plan);

    List<Plan> getAllPlans();

    List<Number> getAllNumbers();

    String saveAllNumbers();

    String updateAvailabilityOfNumber(int numberId);
}
