package com.eMobileConnect.demoPlan.repository;

import com.eMobileConnect.demoPlan.entity.Number;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NumberRepository extends JpaRepository<Number, Integer> {
    List<Number> findByAvailability(String availability);
}
