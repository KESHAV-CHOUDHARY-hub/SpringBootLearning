package com.eMobileConnect.demoPlan.controller;

import com.eMobileConnect.demoPlan.entity.Number;
import com.eMobileConnect.demoPlan.entity.Plan;
import com.eMobileConnect.demoPlan.service.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
public class controller {

    @Autowired
    ServiceImpl service;

    @PostMapping("/Plan")
    public String savePlan(@Valid @RequestBody Plan plan) {
        return service.savePlan(plan);
    }

    @GetMapping("/Plans")
    public List<Plan> getAllPlans() {
        return service.getAllPlans();
    }

    @GetMapping("/Numbers")
    public List<Number> getAllNumbers() {
        return service.getAllNumbers();
    }

    @PostMapping("/Numbers")
    public String saveAllNumbers() {
        return service.saveAllNumbers();
    }

    @PutMapping("/Numbers")
    public String updateAvailabilityOfNumber(@RequestParam int numberId) {
        return service.updateAvailabilityOfNumber(numberId);
    }
}
