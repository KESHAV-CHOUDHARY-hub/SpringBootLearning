package com.eMobileConnect.demoPlan.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Plan {

    @Id
    private int planId;
    @NotNull
    @Size(min = 3, max = 30)
    @Pattern(regexp = "^[a-zA-Z\\s]+$")
    private String planName;
    @Positive
    private int planCost;
    @NotNull
    @Size(min = 5, max = 100)
    private String planDescription;

}
