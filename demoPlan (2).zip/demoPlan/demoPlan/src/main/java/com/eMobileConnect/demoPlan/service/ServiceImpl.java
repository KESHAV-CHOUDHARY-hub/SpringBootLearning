package com.eMobileConnect.demoPlan.service;

import com.eMobileConnect.demoPlan.entity.Number;
import com.eMobileConnect.demoPlan.entity.Plan;
import com.eMobileConnect.demoPlan.repository.NumberRepository;
import com.eMobileConnect.demoPlan.repository.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ServiceImpl implements com.eMobileConnect.demoPlan.service.Service {

    @Autowired
    Repository repository;

    @Autowired
    NumberRepository numberRepository;

    @Override
    public String savePlan(Plan plan) {
         repository.save(plan);
         return "PLAN SAVED";
    }

    @Override
    public List<Plan> getAllPlans() {
        return repository.findAll();
    }

    @Override
    public List<Number> getAllNumbers() {
        List<Number> numbers = new ArrayList<>();
        int check = 0;
        for (Number numbersIteration : numberRepository.findByAvailability("Y")) {
            if (check>=10) {
                break;
            }
            numbers.add(numbersIteration);
            check = check+1;
        }
        return numbers;
    }

    @Override
    public String saveAllNumbers() {
        Long number = 9788119400L;
        for (int i = 1; i<100; i++) {
            number = number + i;
            numberRepository.save(new Number(i, number, "Y"));
        }
        return "Saved 100 Numbers";
    }

    @Override
    public String updateAvailabilityOfNumber(int numberId) {
        Number number = numberRepository.findById(numberId).get();
        number.setAvailability("N");
        numberRepository.save(number);
        return "NUMBER OCCUPIED";
    }
}
